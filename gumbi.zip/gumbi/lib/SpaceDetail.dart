import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'image_slider.dart';

class SpaceDetail extends StatefulWidget {
  DocumentSnapshot document;

  SpaceDetail(DocumentSnapshot document) {
    this.document = document;
  }

  @override
  State<StatefulWidget> createState() => SpaceDetailState(document);
}

class SpaceDetailState extends State<SpaceDetail> {
  DocumentSnapshot document;

  SpaceDetailState(DocumentSnapshot document) {
    this.document = document;
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: new AppBar(
        elevation: 0,
        title: new Text("Space Details"),
        actions: <Widget>[
          IconButton(icon: Icon(Icons.favorite_border), onPressed: () {})
        ],
      ),
      body:
      Column(
        children: <Widget>[
          SizedBox(
            height: 200.0,
            child: Stack(
              children: <Widget>[
                Positioned.fill(
                    child: FutureBuilder(
                        future: imageLoader(document),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData)
                            return const Text('Loading...');
                          return imageSlider(snapshot.data);
                        })),
                Positioned(
                  bottom: 0.0,
                  left: 0.0,
                  right: 0.0,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child:
                    Text(
                      'Length:' +
                          double.parse(document['length']).toString() +
                          'm ,width:' +
                          double.parse(document['width']).toString() +
                          "m",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
          new Container(child:Text(
            document['extra'].toString() + " room "+document['type'].toLowerCase().toString()+" with "+document['bed'].toString()+" bedroom(s), "+document['bath'].toString()+" bathroom(s) and "+document['parking'].toString()+" parking.",
            style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 18.0),
          ),margin: EdgeInsets.all(16.0),),
          new ListTile(
            title: Text(
              document['bed'].toString() +
                  ' Bed • ' +
                  document['bath'].toString() +
                  ' Bath • ' +
                  document['parking'].toString() +
                  " Park",
              style: TextStyle(fontSize: 18.0),
            ),
            subtitle: Text(
              document['address'].toString() +
                  " • " +
                  document['section'].toString() +
                  " • " +
                  document['town'].toString(),
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.0),
            ),
            trailing: Text(
              "R" + double.parse(document['price']).toString(),
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22.0),
            ),
            isThreeLine: true,
          ),
         ListTile(title: Text(document['utilities'],style: TextStyle(fontSize: 16.0,fontWeight: FontWeight.bold),),subtitle: Text('utilities',style: TextStyle(color: Colors.grey.shade700),),leading: Icon(Icons.power,size: 36.0,),),
          ListTile(title: Text(document['date'],style: TextStyle(fontSize: 16.0,fontWeight: FontWeight.bold),),subtitle: Text('listed',style: TextStyle(color: Colors.grey.shade700),),leading: Icon(Icons.person,size: 36.0,),),
          ListTile(title: Text(document['owner'],style: TextStyle(fontSize: 16.0,fontWeight: FontWeight.bold),),subtitle: Text('owner',style: TextStyle(color: Colors.grey.shade700),),leading: Icon(Icons.person,size: 36.0,),),

        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){},
        child: Icon(Icons.chat),),
    );
  }
}
